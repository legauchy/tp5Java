//package testcouple;

public class EmptyTab extends Exception {
    
    public EmptyTab(String parametre) {
        super("Le tableau " + parametre + " est vide!");
    }
}
